1. If you need to upgrade the firmware to version 1.1, you can use the USB cable to connect to the motherboard and power it on.

2. Please check the 'manual' from the folder 'XLoader&GRBL1.1F-CNC3'to upgrade.

3. Then you can use the control software 'Grblcontrol(Candle_1.1.7 )' to control the CNC Router.